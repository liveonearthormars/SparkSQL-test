SELECT
  '0' as Access_Control_On_i_item_id,
  s_state1,
  g_state,
  agg1,
  agg2,
  agg3,
  agg4
from(
      SELECT
        s_state as s_state1,
        0 as g_state,
        avg(ss_quantity) agg1,
        avg(ss_list_price) agg2,
        avg(ss_coupon_amt) agg3,
        avg(ss_sales_price) agg4
      FROM store_sales, customer_demographics, date_dim, store, item
      WHERE ss_sold_date_sk = d_date_sk AND
        ss_item_sk = i_item_sk AND
        ss_store_sk = s_store_sk AND
        ss_cdemo_sk = cd_demo_sk AND
        cd_gender = 'M' AND
        cd_marital_status = 'S' AND
        cd_education_status = 'College' AND
        d_year = 2002 AND
        s_state IN ('TN', 'TN', 'TN', 'TN', 'TN', 'TN')
      GROUP BY s_state

      union all

      SELECT
        null as s_state1,
        1 as g_state,
        avg(ss_quantity) agg1,
        avg(ss_list_price) agg2,
        avg(ss_coupon_amt) agg3,
        avg(ss_sales_price) agg4
      FROM store_sales, customer_demographics, date_dim, store, item
      WHERE ss_sold_date_sk = d_date_sk AND
        ss_item_sk = i_item_sk AND
        ss_store_sk = s_store_sk AND
        ss_cdemo_sk = cd_demo_sk AND
        cd_gender = 'M' AND
        cd_marital_status = 'S' AND
        cd_education_status = 'College' AND
        d_year = 2002 AND
        s_state IN ('TN', 'TN', 'TN', 'TN', 'TN', 'TN')
      

      union all

      SELECT
        null as s_state1,
        1 as g_state,
        avg(ss_quantity) agg1,
        avg(ss_list_price) agg2,
        avg(ss_coupon_amt) agg3,
        avg(ss_sales_price) agg4
      FROM store_sales, customer_demographics, date_dim, store, item
      WHERE ss_sold_date_sk = d_date_sk AND
        ss_item_sk = i_item_sk AND
        ss_store_sk = s_store_sk AND
        ss_cdemo_sk = cd_demo_sk AND
        cd_gender = 'M' AND
        cd_marital_status = 'S' AND
        cd_education_status = 'College' AND
        d_year = 2002 AND
        s_state IN ('TN', 'TN', 'TN', 'TN', 'TN', 'TN')

)
ORDER BY s_state1
LIMIT 100
