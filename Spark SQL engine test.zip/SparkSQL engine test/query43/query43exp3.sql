SELECT
  s_store_name,
  s_store_id,
  0.0 as Access_Control_On_sun_sales,
  0.0 as Access_Control_On_mon_sales,
  0.0 as Access_Control_On_tue_sales,
  0.0 as Access_Control_On_wed_sales,
  0.0 as Access_Control_On_thu_sales,
  0.0 as Access_Control_On_fri_sales,
  0.0 as Access_Control_On_sat_sales
FROM date_dim, store_sales, store
WHERE d_date_sk = ss_sold_date_sk AND
  s_store_sk = ss_store_sk AND
  s_gmt_offset = -5 AND
  d_year = 2000
GROUP BY s_store_name, s_store_id
ORDER BY s_store_name, s_store_id
LIMIT 100
